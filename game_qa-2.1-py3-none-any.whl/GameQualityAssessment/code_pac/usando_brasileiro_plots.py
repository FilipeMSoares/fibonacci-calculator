import wx
from GameQualityAssessment.code_pac.brasileiro.model import Game
from GameQualityAssessment.code_pac.plots.panelPlot import PanelPlot
import GameQualityAssessment.code_pac.plots.brasileiroPlots as bp

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="brasileiro plots",size=(600,600))
        panel = wx.Panel(self)

        tabbed = wx.Notebook(panel,size=(550,550),pos=(10,10))

        obj = Game('2010')

        panel1 = PanelPlot(tabbed)
        panel1.SetSize(500,500)
        bp.points(obj,panel1)
        tabbed.AddPage(panel1,text="Panel1")
        panel1.set_size()
        panel1.draw()

        panel2 = PanelPlot(tabbed)
        panel2.SetSize(500,500)
        bp.positions(obj,panel2)
        tabbed.AddPage(panel2,text="Panel2")
        panel2.set_size()
        panel2.draw()

        panel3 = PanelPlot(tabbed)
        panel3.SetSize(500,500)
        values = []
        for roud in obj.gameRounds:
            for tupli in roud:
                values.append(tupli.totalScore)
        maxi = max(values)
        values = [value/maxi for value in values]
        bp.values_histogram(values,panel3,'Panel3')
        tabbed.AddPage(panel3,text="Panel3")
        panel3.set_size()
        panel3.draw()

        pass

if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()