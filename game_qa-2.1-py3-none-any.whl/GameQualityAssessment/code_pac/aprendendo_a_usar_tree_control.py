import wx

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="Frame aka window")
        panel = wx.Panel(self)

        treeExplorer = wx.TreeCtrl(panel,size=(300,200))
        root = treeExplorer.AddRoot("THIS IS A ROOT")
        child1 = treeExplorer.AppendItem(root,"THIS IS A CHILD 1")
        child2 = treeExplorer.AppendItem(root,"THIS IS A CHILD 2")
        child11 = treeExplorer.AppendItem(child1,"THIS IS A CHILD 11")
        child12 = treeExplorer.AppendItem(child1,"THIS IS A CHILD 12")

        pass

if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()
    pass