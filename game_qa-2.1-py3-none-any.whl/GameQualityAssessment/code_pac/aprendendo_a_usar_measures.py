import GameQualityAssessment.code_pac.brasileiro.model as model
from GameQualityAssessment.code_pac.model import BrasileiroGame, DesafioGame
import GameQualityAssessment.code_pac.measures as measures
import matplotlib.pyplot as pp

if __name__ == "__main__":
    dramas = []
    uncertainties = []
    lead_changes = []
    years = []
    year = 2002
    for game in model.Game.retrieveList():
        year = year + 1
        years.append(year)
        brgame = BrasileiroGame(game)
        drama = measures.DramaByPaths(game=brgame,ignored=0)
        uncertainty = measures.UncertaintyPDD(game=brgame, ignored=0)
        lead_change = measures.LeadChange(game=brgame,ignored=0)
        dramas.append(drama.getMeasureValue())
        uncertainties.append(uncertainty.getMeasureValue())
        lead_changes.append(lead_change.getMeasureValue())
    pp.plot(years,dramas)
    pp.plot(years,uncertainties)
    pp.plot(years,lead_changes)
    pp.show()