import wx
import wx.grid as wxg
from GameQualityAssessment.code_pac.model import BrasileiroGame
from GameQualityAssessment.code_pac.brasileiro import model
from GameQualityAssessment.code_pac.measures import DramaByPaths as Drama, UncertaintyPDD as Uncertainty, LeadChange
import GameQualityAssessment.code_pac.plots.brasileiroPlots as bp
from GameQualityAssessment.code_pac.plots.panelPlot import PanelPlot

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="All events")
        panel = wx.Panel(self)
        
        self.gameExplorer = wx.TreeCtrl(panel,pos=(10,10),size=(100,160))
        self.panel_show = wx.Notebook(panel,pos=(10,170),size=(300,300))
        self.table = wxg.Grid(panel,pos=(110,10),size=(200,160))
        
        root = self.gameExplorer.AddRoot("Games")
        self.__fill_tree(self.gameExplorer,root)
        self.gameExplorer.Bind(wx.EVT_TREE_SEL_CHANGED,self.__set_table_data)

        self.table.CreateGrid(4,1)
        for x in range(0,4) :
            self.table.SetReadOnly(x,0)
        self.table.SetRowLabelSize(100)
        self.table.SetRowLabelValue(0,"Drama")
        self.table.SetRowLabelValue(1,"Uncertainty")
        self.table.SetRowLabelValue(2,"Lead Change")
        self.table.SetRowLabelValue(3,"Overall Eval.")
        self.table.SetColLabelValue(0,"Value")
        self.table.SetColSize(0,100)
        
        self.__set_table_data(None)
    
    def __fill_tree(self,gameExplorer,root):
        games = model.Game.retrieveList()
        for game in games :
            gameExplorer.AppendItem(root,game.year,data=game)
    
    def __set_table_data(self,event):
        selected = self.gameExplorer.GetSelection()
        dramas = []
        uncertainties = []
        leadChanges = []
        games = None
        if (not selected.IsOk() ) or (self.gameExplorer.GetItemData(selected) == None) :
            games = model.Game.retrieveList()
        else:
            games = [self.gameExplorer.GetItemData(selected)]
        
        for data in games: 
            brgame = BrasileiroGame(data)
            dramas.append(Drama(game=brgame,ignored=0).getMeasureValue())
            uncertainties.append(Uncertainty(game=brgame,ignored=0).getMeasureValue())
            leadChanges.append(LeadChange(game=brgame,ignored=0).getMeasureValue())
        avg_drama = sum(dramas)/len(dramas)
        avg_uncertainties = sum(uncertainties)/len(uncertainties)
        avg_leadChanges = sum(leadChanges)/len(leadChanges)

        self.table.SetCellValue(0,0,str(avg_drama))
        self.table.SetCellValue(1,0,str(avg_uncertainties))
        self.table.SetCellValue(2,0,str(avg_leadChanges))
        self.table.SetCellValue(3,0,str( (avg_drama+avg_uncertainties+avg_leadChanges)/3 ))

        for index in range(0,self.panel_show.GetPageCount()):
            page = self.panel_show.GetPage(0)
            self.panel_show.RemovePage(0)
            page.Destroy()
        
        if len(games) > 1:
            histogram_panel = PanelPlot(self.panel_show)
            histogram_panel.SetSize(180,180)
            evals = []
            for index in range(0,len(dramas)) :
                evals.append((dramas[index]+uncertainties[index]+leadChanges[index])/3)
            bp.values_histogram(evals,histogram_panel)
            self.panel_show.AddPage(histogram_panel,"Histogram (Overall Eval.)")
            histogram_panel.set_size()
            histogram_panel.draw()
        else:
            position_panel = PanelPlot(self.panel_show)
            position_panel.SetSize(180,180)
            bp.positions(games[0],position_panel)
            point_panel = PanelPlot(self.panel_show)
            point_panel.SetSize(180,180)
            bp.points(games[0],point_panel)
            self.panel_show.AddPage(position_panel, "History by Positions")
            self.panel_show.AddPage(point_panel, "History by Points")
            position_panel.set_size()
            position_panel.draw()
            point_panel.set_size()
            point_panel.draw()


if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()