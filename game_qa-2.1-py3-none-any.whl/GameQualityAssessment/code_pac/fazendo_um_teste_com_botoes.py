import wx

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="something")
        panel = wx.Panel(self)
        button = wx.Button(panel,label="algo")

        tp = wx.Notebook(panel,pos=(10,100),size=(100,100))

        panel2 = wx.Panel(tp)
        tp.AddPage(panel2,"something")
        label = wx.StaticText(panel2,label="something")

if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    app.frame = frame
    frame.Show()
    app.MainLoop()