import wx
import wx.grid

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="SoMeThInG")

        panel = wx.Panel(self)

        table = wx.grid.Grid(panel,pos=(10,10),size=(300,110))
        table.CreateGrid(4,1)

        table.SetColLabelValue(0,"Value")
        table.SetColSize(0,180)

        table.SetRowLabelValue(0,"Drama")
        table.SetRowLabelValue(1,"Uncertainty")
        table.SetRowLabelValue(2,"Lead Change")
        table.SetRowLabelValue(3,"Overall Evaluation")
        table.SetRowLabelSize(120)
        table.SetRowLabelAlignment(wx.ALIGN_LEFT,wx.ALIGN_CENTRE)

        for row in range(0,4):
            table.SetReadOnly(row,0,True)
            table.SetReadOnly(row,1,True)
        
        pass

if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()