import wx
import GameQualityAssessment.code_pac.brasileiro.model as model
from GameQualityAssessment.code_pac.model import BrasileiroGame

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="THE GAMES",size=(300,300))
        panel = wx.Panel(self)

        gameExplorer = wx.TreeCtrl(panel,pos=(10,10),size=(260,240))
        root = gameExplorer.AddRoot("Games:")
        
        games = model.Game.retrieveList()

        for game in games :
            gameExplorer.AppendItem(root,game.year)
            pass

        pass

if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()
    pass