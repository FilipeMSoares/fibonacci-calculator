import wx
import wx.grid
import GameQualityAssessment.code_pac.brasileiro.model as model
from GameQualityAssessment.code_pac.model import BrasileiroGame
import GameQualityAssessment.code_pac.measures as measures

def years_list():
    years = []
    for game in model.Game.retrieveList():
        years.append(game.year)
    return years

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="Measures")
        panel = wx.Panel(self)

        self.table = wx.grid.Grid(panel,pos=(10,50),size=(300,110))

        years = years_list()
        self.comboBox = wx.ComboBox(panel,pos=(10,10),choices=years)
        self.comboBox.SetEditable(False)
        self.comboBox.Bind(wx.EVT_COMBOBOX,self.updateTable)
        self.comboBox.SetValue(years[0])
        
        self.table.CreateGrid(4,1)

        self.table.SetColLabelValue(0,"Value")
        self.table.SetColSize(0,180)

        self.table.SetRowLabelValue(0,"Drama")
        self.table.SetRowLabelValue(1,"Uncertainty")
        self.table.SetRowLabelValue(2,"Lead Change")
        self.table.SetRowLabelValue(3,"Overall Evaluation")
        self.table.SetRowLabelAlignment(wx.ALIGN_LEFT,wx.ALIGN_CENTRE)
        self.table.SetRowLabelSize(120)

        game = model.Game(years[0])
        br_game = BrasileiroGame(game)

        drama = measures.DramaByPaths(game=br_game,ignored=0)
        uncertainty = measures.UncertaintyPDD(game=br_game,ignored=0)
        lead_change = measures.LeadChange(game=br_game,ignored=0)
        overall_evaluation = (drama.getMeasureValue()+uncertainty.getMeasureValue()+lead_change.getMeasureValue())/3.0

        self.table.SetCellValue(0,0,str(drama.getMeasureValue()))
        self.table.SetCellValue(1,0,str(uncertainty.getMeasureValue()))
        self.table.SetCellValue(2,0,str(lead_change.getMeasureValue()))
        self.table.SetCellValue(3,0,str(overall_evaluation))

        pass

    def updateTable(self,event):
        game = model.Game(self.comboBox.GetValue())
        br_game = BrasileiroGame(game)

        drama = measures.DramaByPaths(game=br_game,ignored=0)
        uncertainty = measures.UncertaintyPDD(game=br_game,ignored=0)
        lead_change = measures.LeadChange(game=br_game,ignored=0)
        overall_evaluation = (drama.getMeasureValue()+uncertainty.getMeasureValue()+lead_change.getMeasureValue())/3.0

        self.table.SetCellValue(0,0,str(drama.getMeasureValue()))
        self.table.SetCellValue(1,0,str(uncertainty.getMeasureValue()))
        self.table.SetCellValue(2,0,str(lead_change.getMeasureValue()))
        self.table.SetCellValue(3,0,str(overall_evaluation))


if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()