import wx
from GameQualityAssessment.code_pac.plots.panelPlot import PanelPlot

class bucky(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="panel plot")
        panel = wx.Panel(self)

        tabbed = wx.Notebook(panel,pos=(10,10),size=(250,250))
        
        panel1 = PanelPlot(tabbed)
        panel1.SetSize(200,200)
        panel1.figure.clf()
        graphical = panel1.figure.gca()
        graphical.hist(['A','B','B','C','C','D'])
        panel1.set_size()
        panel1.draw()
        tabbed.AddPage(panel1,"Histogram")

        panel2 = PanelPlot(tabbed)
        panel2.SetSize(200,200)
        panel2.figure.clf()
        graphical = panel2.figure.gca()
        graphical.plot([1,2,3,4],[1,1,3,4],'o-',lineWidth=2)
        graphical.plot([1,2,3,4],[2,2,2,1],'o-',lineWidth=2)
        graphical.plot([1,2,3,4],[3,3,4,3],'o-',lineWidth=2)
        graphical.plot([1,2,3,4],[4,4,1,2],'o-',lineWidth=2)
        graphical.invert_yaxis()
        panel2.set_size()
        panel2.draw()
        tabbed.AddPage(panel2,"Graph")

if __name__ == "__main__":
    app = wx.App()
    frame = bucky()
    frame.Show()
    app.MainLoop()