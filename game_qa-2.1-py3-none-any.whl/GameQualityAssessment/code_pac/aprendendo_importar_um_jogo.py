import GameQualityAssessment.code_pac.ingles.model as model
from GameQualityAssessment.code_pac.model import PremierLeagueGame

if __name__ == "__main__":
    the_game = model.Game('1993')
    var = PremierLeagueGame(the_game)
    print("The players: ",var.getPlayers())
    print("The round 1: ",var.getRound(1))
    print("The number of rounds: ",var.getNumberRounds())
    print("The last round: ",var.getLastRound())
    print("The winner: ",var.getWinner())
    