import wx

class bucky(wx.Frame):
    def __init__(self,parent):
        wx.Frame.__init__(self,parent,title="Tabbed pane window",size=(300,200))
        main_panel = wx.Panel(self)

        tabbed_pane = wx.Notebook(main_panel, size=(100,100))

        panel1 = wx.Panel(tabbed_pane)
        label1 = wx.StaticText(panel1,label="alguma coisa",pos=(10,10))
        tabbed_pane.AddPage(panel1,"Tab1")

        panel2 = wx.Panel(tabbed_pane)
        label2 = wx.StaticText(panel2,label="ALGUMA COISA",pos=(10,10))
        tabbed_pane.AddPage(panel2,"Tab2")

        #se nao for definido o tamanho do tabbed pane, é necessário adicionar estas linhas
        #sizer = wx.BoxSizer()
        #sizer_panel = wx.BoxSizer()
        #sizer_panel.Add(tabbed_pane,1,wx.EXPAND)
        #sizer.Add(main_panel,1,wx.EXPAND)
        #main_panel.SetSizer(sizer_panel)
        #self.SetSizer(sizer)

        pass

if __name__=="__main__":
    app = wx.App()
    app.frame = bucky(None)
    app.frame.Show()
    app.MainLoop()
    pass